import csv
import json
import os
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

load_dotenv()

ENDPOINT = "https://api.nugen.in/api/v3/inference/completions"
MODEL_ID = os.environ["NUGEN_MODEL_ID"]
API_KEY = os.environ["NUGEN_API_KEY"]

BENCHMARK_FILE = Path(os.getenv("BENCHMARK_FILE", "nugen_fhir_benchmark.json"))
DOMAIN_DIR = Path(os.getenv("DOMAIN_DIR", "domain_docs"))
OUTPUT_JSON = Path(os.getenv("OUTPUT_JSON", "grounded_results.json"))
OUTPUT_CSV = Path(os.getenv("OUTPUT_CSV", "grounded_results.csv"))
TIMEOUT = int(os.getenv("NUGEN_TIMEOUT", "180"))

QUESTION_SOURCES = {
    1: ["01_fhir_core_resources.txt"],
    2: ["01_fhir_core_resources.txt", "02_observation_and_results.txt"],
    3: ["01_fhir_core_resources.txt", "02_observation_and_results.txt"],
    4: ["01_fhir_core_resources.txt", "02_observation_and_results.txt"],
    5: ["02_observation_and_results.txt"],
    6: ["03_conditions_allergies_medications.txt"],
    7: ["03_conditions_allergies_medications.txt"],
    8: ["01_fhir_core_resources.txt", "04_patient_encounter_workflow.txt"],
    9: ["04_patient_encounter_workflow.txt"],
    10: ["01_fhir_core_resources.txt", "04_patient_encounter_workflow.txt"],
    11: ["03_conditions_allergies_medications.txt"],
    12: ["03_conditions_allergies_medications.txt"],
    13: ["05_healthcare_prior_authorization_and_fhir.txt"],
    14: ["05_healthcare_prior_authorization_and_fhir.txt"],
    15: ["05_healthcare_prior_authorization_and_fhir.txt"],
}

def load_context(question_id):
    chunks = []
    for filename in QUESTION_SOURCES[question_id]:
        chunks.append(
            f"--- {filename} ---\n"
            + (DOMAIN_DIR / filename).read_text(encoding="utf-8")
        )
    return "\n\n".join(chunks)

def ask_model(question, context):
    prompt = f"""You are a healthcare data assistant specializing in HL7 FHIR.

Use the domain reference below as the authoritative context for this answer.

Rules:
- Answer the question directly.
- Use only FHIR resources, fields, and relationships supported by the reference.
- Do not invent resource types, fields, or relationships.
- If the reference does not contain enough information, explicitly say what is missing.
- Prefer concise, precise answers over unnecessary detail.

DOMAIN REFERENCE:
{context}

QUESTION:
{question}

ANSWER:
"""
    payload = {
        "model": MODEL_ID,
        "prompt": prompt,
        "max_tokens": 500,
        "temperature": 0.2,
        "stream": False,
    }

    started = time.perf_counter()
    response = requests.post(
        ENDPOINT,
        headers={
            "Authorization": f"Bearer {API_KEY}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=TIMEOUT,
    )
    elapsed = time.perf_counter() - started
    response.raise_for_status()
    data = response.json()
    choice = (data.get("choices") or [{}])[0]

    return {
        "answer": choice.get("text", ""),
        "finish_reason": choice.get("finish_reason"),
        "latency_seconds": round(elapsed, 3),
        "usage": data.get("usage"),
        "confidence": data.get("confidence"),
        "raw_response": data,
    }

def main():
    benchmark = json.loads(BENCHMARK_FILE.read_text(encoding="utf-8"))
    results = []
    total_started = time.perf_counter()

    for index, item in enumerate(benchmark, start=1):
        print(f"[{index}/{len(benchmark)}] {item['question']}")
        try:
            result = ask_model(item["question"], load_context(index))
            row = {
                "id": index,
                "question": item["question"],
                "expected_answer": item["answer"],
                "source_documents": QUESTION_SOURCES[index],
                "model_answer": result["answer"],
                "finish_reason": result["finish_reason"],
                "latency_seconds": result["latency_seconds"],
                "usage": result["usage"],
                "confidence": result["confidence"],
                "error": None,
                "raw_response": result["raw_response"],
            }
            print(f"  OK - {result['latency_seconds']}s")
        except Exception as exc:
            row = {
                "id": index,
                "question": item["question"],
                "expected_answer": item["answer"],
                "source_documents": QUESTION_SOURCES[index],
                "model_answer": "",
                "finish_reason": None,
                "latency_seconds": None,
                "usage": None,
                "confidence": None,
                "error": str(exc),
                "raw_response": None,
            }
            print(f"  ERROR - {exc}")
        results.append(row)

    successful = [r for r in results if r["error"] is None]
    summary = {
        "experiment": "aligned_model_with_domain_grounding",
        "model_id": MODEL_ID,
        "question_count": len(results),
        "successful_requests": len(successful),
        "failed_requests": len(results) - len(successful),
        "total_time_seconds": round(time.perf_counter() - total_started, 3),
        "average_latency_seconds": round(
            sum(r["latency_seconds"] for r in successful) / max(1, len(successful)), 3
        ),
    }

    OUTPUT_JSON.write_text(
        json.dumps({"summary": summary, "results": results}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    with OUTPUT_CSV.open("w", newline="", encoding="utf-8") as f:
        fields = [
            "id", "question", "expected_answer", "source_documents",
            "model_answer", "finish_reason", "latency_seconds",
            "confidence", "error"
        ]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in results:
            row = dict(r)
            row["source_documents"] = ", ".join(r["source_documents"])
            writer.writerow({field: row.get(field) for field in fields})

    print("\nDone.")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
