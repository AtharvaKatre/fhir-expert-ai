# Nugen FHIR Alignment Experiment Report

## Objective
Compare the deployed FHIR-aligned model with and without relevant domain
grounding at inference time.

## Results

| Experiment | Correct | Partial | Incorrect | Avg latency |
|---|---:|---:|---:|---:|
| Aligned model only | 4 | 5 | 6 | 2.73s |
| Aligned + domain grounding | TBD | TBD | TBD | TBD |

## Findings
TBD after the grounded run.

## Application
After evaluating the model, build a small application that sends inference
requests to the deployed aligned model. The application should demonstrate
a useful domain workflow, not just a raw API call.

Planned stack:
- FastAPI
- Nugen aligned-model integration
- FHIR resource validation
- Structured responses
- Automated tests
- Docker
- README and example requests
